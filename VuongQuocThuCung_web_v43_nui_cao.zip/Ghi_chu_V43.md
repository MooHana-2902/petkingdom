# Ghi chú bàn giao V43

Bản xây dựng ngày 20/10/2026, từ file HTML V42 do người dùng cung cấp. Các điều chỉnh được xác nhận trong hội thoại được ưu tiên hơn nội dung tài liệu cũ.

- Địa hình mới có hình riêng và nút icon ⓘ mở bảng thông tin; không đặt luật dài trên ô chơi. Bấm xem không di chuyển và không mất năng lượng.
- Thêm Rừng Rậm, Núi Cao, đầm lầy cố định, tơ Nhện tạm; khai thác chủ động từng lần. Thêm Cá Sấu với lãnh thổ đầm lầy nối chuỗi, đớp ban ngày và tương tác với Ếch/Cú.
- Túi đầy tăng 1⚡ cho đi/đánh; Mệt giảm 1⚡ tối đa. Bỏ một ô tài nguyên bằng ×: miễn phí, mất vĩnh viễn. Đồ trang bị rơi do tử trận Khó là cơ chế riêng, có thể nhặt lại.
- Làm mờ vùng bị vật cản che; ẩn thông số Quái trong vùng mờ. Giữ dấu Thành đã biết và dấu vị trí Quái cũ theo từng tổ. Sửa phát hiện Thành và vùng soi riêng của Cú/Bùa Tinh Tú.
- Xem hồ sơ, tab Thành và Kho không đổi đội đang điều khiển. Không dừng chung ô ngoài ngoại lệ khách thăm; kiểm tra lại điểm đáp Cáo/cổng.
- Chuyển Thủ từ trang bị thành Máu tối đa; thêm Khiên Ảo tạm. Tháp cấp 0 không bắn; pha Quái theo thứ tự đánh → di chuyển → mỗi Tháp bắn một mục tiêu máu thấp nhất. Trang bị V42 được chuyển đổi một lần khi đọc bản lưu.
- Corgi hỗ trợ bằng cờ; Quái ngủ hồi máu; Quái Lv.5 có sao Cuồng Hoá theo dòng hồi sinh. Máy tìm đường theo tiêu hao, nhặt Sao/đồ rơi, về nghỉ/sửa, ưu tiên xây Tháp.
- Helping Hand dùng đăng ký và bốc thăm cho cả người và Máy. Hai công tắc canh lực đánh Quái / canh Trộm riêng. Trộm đang chạy không huỷ được; hết 5 giây tính thất bại, tiêu hao và hồi chiêu.
- Thẻ kết quả Trộm/Công Thành gọn, ảnh giao chiến theo hình trên bản đồ. Có camera cảnh Thành bị Quái đánh, nút Tiếp/Bỏ qua và tuỳ chọn tắt.
- Luồng tạo ván Chọn lớp → Chia tổ → Bắt đầu, kích thước bản đồ tự tính, thiết lập sâu thu gọn, nút thưởng/câu hỏi/lưu lớp dễ mở. Lưu lớp có kiểm tra dữ liệu và ghi vào IndexedDB, hỗ trợ xuất/nhập JSON.
- Hình Rừng Rậm, Núi Cao, Đầm Lầy và Cá Sấu đã được nhúng trong HTML, không cần tải ảnh từ mạng. Công cụ tạo ảnh hiện có không cung cấp bộ chọn model GPT 2.5.

## Kiểm tra

44/44 tình huống tự động về luật, tích hợp và hồi quy đã qua, không ghi nhận lỗi JavaScript trong các lượt kiểm tra đó. Kiểm tra giao diện bằng Chromium ở kích thước 1440×900 và 390×844: tạo ván, xem hồ sơ không đổi tổ, bỏ tài nguyên, lưu/tải lớp và tải lại trang. Kiểm tra bấm icon địa hình không mất lượt, luồng đánh thật, trộm hết giờ, cảnh camera/skip và tải PWA khi mất mạng.

Đây là kiểm tra trình duyệt và điện thoại mô phỏng; chưa xác nhận trực tiếp trên iOS thật hay bảng tương tác.

## Mô phỏng so với V42

Mỗi bản chạy 6 ván Máy, 4 tổ/ván, 80 buổi/ván; 3 hạt ngẫu nhiên ở Lớp Lớn và 3 ở Khó. Cùng cấu hình ban đầu; V43 có thêm luật và thuật toán Máy mới nên diễn biến ngẫu nhiên không trùng từng bước.

| Chỉ số | V42 | V43 |
|---|---:|---:|
| Tổng lần tử trận | 12 | 9 |
| Tổng lần Thành bị phá | 29 | 11 |
| Điểm trung bình cuối ván mỗi tổ | 5961 | 7588 |
| Tổ đạt Thành Lv3 / 24 | 21 | 22 |
| Tổ đạt Thành Lv5 / 24 | 7 | 12 |

Lớp Lớn: ngày trung bình đạt Lv3 là 10,2 → 9,1; Lv5 là 17,8 → 17,5 (chỉ tính tổ đã đạt).
Khó: ngày trung bình đạt Lv3 là 11,1 → 13,2; Lv5 là 19,5 → 20,0 (chỉ tính tổ đã đạt).

Kết quả mẫu cho thấy giảm số Thành bị phá, giảm tổng tử trận và tăng điểm; chưa đủ để kết luận cân bằng ở mọi cấu hình hoặc tách riêng tác động của trang bị và AI. Chưa tăng đồng loạt sát thương Quái; giữ trần/ngưỡng Cuồng Hoá chỉnh được trong cài đặt.

## Cập nhật Cổng dịch chuyển

Đứng lên, đi ngang hoặc đáp bằng kỹ năng không tự kích hoạt cổng. Khi đứng trên cổng, nút hành động đổi thành “Dịch chuyển”, tốn đúng 1⚡ kể cả túi đầy. Mỗi linh thú dùng tối đa một lần trong một buổi chung; đổi tổ không làm mới, qua buổi mới dùng lại được. Cơ chế này thay hồi chiêu 3 buổi cũ. Hạn dùng được lưu theo tiến trình lớp. Điểm thưởng cổng theo đợt xáo trộn giữ như trước, chỉ nhận khi thực sự dùng cổng. Máy cũng phải chủ động dùng và trả 1⚡. Nếu điểm đến bị chiếm, đáp ô hợp lệ gần nhất.

Đã kiểm tra thêm 12 tình huống liên quan đến cổng và thao tác bấm nút trên giao diện.

## Chỉnh nút thông tin địa hình

Bỏ biểu tượng địa hình lớn và ô nền vuông; chỉ giữ chữ i nhỏ trong vòng tròn ở góc ô, vùng bấm trong suốt. Áp dụng cho Rừng Rậm, Núi Cao, Đầm Lầy, Cổng và Tơ Nhện. Bấm vẫn mở thông tin, không di chuyển hay mất năng lượng. Giữ thay đổi Cổng chủ động 1⚡, một lần mỗi linh thú mỗi buổi.

## Cập nhật Núi Cao và Rương Báu

Tách tài nguyên khai thác và nền Núi Cao. Núi có đá có thêm hình cụm đá; hết đá thì hình cụm đá biến mất. Cả núi còn mỏ và núi cạn đều tốn 2⚡ để leo (cộng phụ phí túi đầy nếu có), cho +1 tầm nhìn và nhìn qua vật cản. Núi có gỗ dùng dấu hình gỗ riêng. Rừng Rậm vẫn mất địa hình khi khai thác hết theo luật trước.

Rương có thể xuất hiện trên Núi Cao, bao gồm cả núi có mỏ. Mở rương tốn 1⚡, không trừ số lần khai thác mỏ; nút hành động vẫn ghi Mở Rương. Sau đó có thể khai thác tài nguyên bên dưới. Các địa hình mới tiếp tục dùng nút i nhỏ.

10/10 tình huống mới đã qua: mỏ cạn, chi phí leo, lợi thế tầm nhìn, rương trên núi, mỏ dưới rương, túi đầy, sinh địa hình, lưu/tải và phân biệt hình trên giao diện. 24/24 tình huống luật nền V43 cũng đã qua. Đã xem và bấm thông tin trên bố cục máy tính/điện thoại mô phỏng.

## Bản gộp và rà soát ngày 21/10/2026

Thêm né 25% từ Núi Cao đối với đòn từ đồng bằng; hai bên cùng trên núi không cộng né. Chi tiết kiểm tra bộ nhớ, tối ưu và giới hạn của số đo nằm trong Ra_soat_V43.md đi kèm.

## Cập nhật camera và công cụ

Mặc định camera 5×5. Đưa ba mức zoom cùng nút về linh thú ra thanh luôn hiện trên bản đồ. Gom công cụ thành Linh thú & Tổ, Lớp học, Cài đặt & Luật; chuyển nút gốc để giữ hành vi cửa sổ và bỏ các nút trùng trên header. Giữ Đổi Tổ / Qua Buổi cạnh thao tác chơi. Chỉnh bố cục điện thoại để sáu nút thao tác không bị ép chiều ngang.

Kiểm tra cập nhật camera: Chromium 1920×1080, 1366×768 và điện thoại mô phỏng 390×844. Ba mức zoom, nút về linh thú, mở Kho/Lưu lớp/Luật qua nhóm công cụ, trở về 5×5 khi tải lại và tạo ván đều qua. Kiểm tra lưu/tải lớp, bỏ tài nguyên, giao chiến, trộm hết giờ, cảnh Thành và PWA tải ngoại tuyến vẫn qua; không có lỗi JavaScript trong các lượt kiểm tra này.

## Bốc thăm tổ đi đầu và camera Máy

Bốc thăm đều từ toàn bộ tổ mỗi buổi, sau đó xoay vòng thứ tự từ tổ trúng; lưu kết quả theo buổi. Máy được chọn đầu tự hành động trước tổ người chơi, các Máy còn lại được xử lý khi đi qua bằng Đổi Tổ hoặc khi Qua Buổi. Ghi nhận Máy đã xong để tránh chạy lại.

AI dùng chung một bộ sinh thao tác cho chạy đồng bộ và xem từng thao tác. Camera 3×3 theo Máy chỉ khi vị trí Máy nhìn rõ qua một tổ người chơi; vùng mờ / ngoài tầm không kích hoạt camera. Trả lại đội điều khiển và góc nhìn cũ khi xong, có nút Xem nhanh. Dừng tác vụ khi đổi ván/lớp; giữ tiến độ khi tải lại. Sửa căn camera theo vị trí ô trên màn hình để không lệch sau thay đổi zoom hoặc bố cục điện thoại.

Kiểm tra bàn giao lần này: 91/91 tình huống luật / tích hợp / hồi quy / thứ tự / quan sát Máy đều qua. Kiểm tra thực tế Chromium trên máy tính và điện thoại mô phỏng: theo Máy, vị trí camera, khoá thao tác người khi xem, Xem nhanh, phục hồi giữa lượt, giữ kết quả bốc thăm và trả camera; không có lỗi JavaScript trong các lượt này. Mô phỏng 6 ván toàn Máy theo thứ tự bốc thăm mới, mỗi ván 80 buổi, không ghi nhận lỗi. Kiểm tra giao chiến, trộm, cảnh Thành và PWA tải lại ngoại tuyến vẫn qua.

## Xáo trộn tài nguyên độc lập với địa hình

Bản trước gọi lại phần tạo địa hình sau khi rải tài nguyên, làm núi đổi vị trí và thay tài nguyên ngẫu nhiên bằng mỏ gỗ/đá. Đã giữ nguyên lớp nền khi xáo trộn; dùng bộ rải tài nguyên hiện có trên toàn bộ ô không phải Thành, không lọc theo nền. Bộ bài tài nguyên và các ô đích dùng Fisher–Yates. Không tạo lại núi hoặc dời lãnh thổ Cá Sấu trong đợt xáo trộn tài nguyên. Cá Sấu cũng không chuyển núi cạn thành đầm lầy.

Làm mới trữ lượng theo tài nguyên mới, không giữ mỏ ẩn cũ dưới tinh thể/rương mới. Đá trong Rừng Rậm không xoá rừng; lấy hết gỗ vẫn chuyển thành đồng bằng theo luật cũ. Giữ icon i nhỏ và bổ sung hình gỗ/đá/💎/rương trên nền địa hình; thông tin núi hiển thị đúng khi có tinh thể. Cổng trên địa hình có một nút i, liên kết xem luật nền bên trong popup.

Kiểm tra mới: 11/11 nhóm tình huống qua, gồm 80 bản rải khác nhau với đủ 16 tổ hợp nền–tài nguyên, 40 lần giữ nguyên nền, thu thập đủ 16 tổ hợp với 1⚡, chu kỳ tự động 2 ngày, giữ Thành/Sao/đồ rơi/cặp cổng và lãnh thổ Cá Sấu. Kiểm tra bấm icon và nhặt tinh thể trên núi ở máy tính và điện thoại mô phỏng đều qua. Mô phỏng 6 ván Máy × 80 buổi không ghi nhận lỗi; kiểm tra giao chiến, trộm, cảnh Thành và PWA ngoại tuyến vẫn qua.

Tổng kiểm tra hồi quy và cập nhật lần này: 102/102 tình huống qua.
