# Rà soát V43 — 21/10/2026

Đã gộp thay đổi V43 vào một bundle khi xây dựng, giữ các mô-đun nguồn để chỉnh sửa. Bỏ vòng canh lực V37 trùng với V32 và lớp Proxy bọc `document.getElementById`; giữ một driver dùng cùng vị trí con trỏ cho hiển thị và kết quả. Bỏ phần cổng tự kích hoạt cũ và pha tấn công cũ đã bị thay thế; gộp phần sát thương, đồ rơi và Khiên Ảo vào luồng chung. Nền giao diện tương thích vẫn giữ thứ tự khởi tạo.

Các điểm xử lý bộ nhớ và tác vụ:

- Ảnh nền địa hình dùng CSS chung theo loại, không chép data URL vào từng ô khi vẽ lại.
- Bộ đệm ảnh Thành đổi màu giới hạn 32 biến thể, tối đa 64 quy tắc CSS; dùng CSSOM để thêm/xoá từng cặp quy tắc, không phân tích lại toàn bộ CSS.
- Cache đường đi giới hạn 32 mục; cache nguồn tầm nhìn dùng lại trong một lần cập nhật và bị xoá khi trạng thái đổi.
- Bộ nhớ gốc phục vụ dịch giao diện bỏ tham chiếu tới DOM đã tháo sau mỗi lượt dịch.
- Các cảnh Thành, mũi tên, bốc thăm và cảnh giao chiến dùng nhóm tác vụ có chủ sở hữu. Bỏ qua cảnh/đổi ván/đổi lớp hủy timeout, interval, animation và DOM liên quan. Hủy cả callback xác nhận giao chiến cũ.
- Thông báo nhỏ bị đẩy khỏi màn hình cũng hủy các timeout giữ phần tử đó.

## Đo trước/sau

Chromium không giao diện, kích thước 1440×900, bản đồ có nhiều địa hình để tạo tải; thay màu Thành 40 lần, bật English và vẽ lại tiếp. Thu gom rác bằng CDP trước mỗi lần ghi nhận. Đây là bài thử tổng hợp tại máy xây dựng, không phải cam kết tốc độ hoặc bộ nhớ trên mọi thiết bị.

| Chỉ số | Trước | Sau |
|---|---:|---:|
| Thời gian vẽ lại trung bình / 40 lượt | 198.6 ms | 34.5 ms |
| Số ký tự style nội tuyến trên các ô địa hình | 16,780,118 | 127 |
| DOM node, English sau 15 / 55 / 95 lượt | — | 5299 / 5299 / 5299 |
| Listener, English sau 15 / 55 / 95 lượt | — | 448 / 448 / 448 |
| JS heap sau GC, English sau 15 / 55 / 95 lượt | — | 5.2 / 5.23 / 5.32 MiB |

DOM và listener không tích lũy trong đoạn thử dài. Heap dao động/tăng nhẹ trong khoảng trên; số đo này không chứng minh mọi đường chạy đều hết rò rỉ. Đã kiểm tra thêm việc hủy tác vụ khi đổi ván và bỏ qua cảnh. Một vòng RAF cho canh lực; sau reset không còn vòng đó. Kết quả canh lực trùng vị trí con trỏ.

## Luật né trên Núi Cao

Linh thú hoặc Quái ở Núi Cao có 25% cơ hội né trọn đòn từ bên ở nền đồng bằng. Hai bên cùng trên núi không có lợi thế né địa hình. Núi cạn tài nguyên vẫn được tính là Núi Cao. Áp dụng cho đòn thường, phản đòn, đòn pha Quái, kỹ năng gây sát thương và đạn Tháp; không né thiệt hại môi trường, HP hi sinh hoặc hình phạt Trộm. Nội tại giảm sát thương riêng giữ nguyên. Hoạt ảnh giao chiến và sát thương thực dùng một kết quả né, không bốc lại.

82/82 tình huống tự động đã qua: 24 luật nền, 12 tích hợp, 8 hồi quy, 10 núi/rương, 12 cổng, 16 né và vòng đời tác vụ. Kiểm tra giao diện máy tính/điện thoại mô phỏng, canh lực, Trộm 5 giây, camera/skip, lưu/tải lớp và PWA tải lại khi mất mạng đã qua. Sáu ván Máy × 80 buổi chạy không ghi nhận lỗi JavaScript hay chỉ số không hợp lệ. Chưa kiểm tra trực tiếp trên bảng tương tác hoặc iOS thật.
